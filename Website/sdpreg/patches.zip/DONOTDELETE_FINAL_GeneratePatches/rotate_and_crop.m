function [ im_out ] = rotate_and_crop(im_in,angle)

[ht,wd] = size(im_in);

im_rotated = imrotate(im_in,angle,'bilinear');
[rot_ht,rot_wd] = size(im_rotated);
im_out = im_rotated(floor(rot_ht/2) - ht/4 + 1 : floor(rot_ht/2) + ht/4, floor(rot_wd/2) - wd/4 + 1 : floor(rot_wd/2) + wd/4);

end

