% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
% Script for generating dataset
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

clear all
close all

% Input directory
DATASET = 'gulls';

% Parameters
bpx = 16;
bpy = 16;                   % Dimensions of segmented image
tr_frac = 0.9;              % Training size
te_frac = 0.1;             % Test size

% Provide a random seed to select a random subset
seed =  2506416722;

n = 7200;
fprintf(strcat('Using dataset: ',DATASET,'\n'));
tr = floor(tr_frac*n);
te = floor(te_frac*n);

px = bpx/2;
py = bpy/2;
d = px*py;

% Load data set
count = 0;
PATH = strcat(DATASET);
ddir = dir(PATH);
TOTAL_IMGS = 378;
Y_RAW = zeros(bpx,bpy,TOTAL_IMGS);
THRESHOLD = 32;

mural = zeros(px*5,px*5);

for f = 3 : length(ddir)
    filename = ddir(f).name;
    img_raw = imread(strcat(PATH,'\',filename));
    img_gray = rgb2gray(img_raw);
    for ii = 1 : (320/bpx)
    for jj = 1 : (320/bpy)
        img_cut = double(img_gray( (ii-1)*bpx+1:ii*bpx, (jj-1)*bpy+1:jj*bpy ));
        img_vec = img_cut(:);
        if std(img_vec) > THRESHOLD
            count = count + 1;
            Y_RAW(:,:,count) = img_cut;
            
            
            if mod(count, 3) == 0 && count <= 300
                xx = ceil(count/30);
                yy = mod(count/3,10)+1;
                mural((xx-1)*px+1:xx*px , (yy-1)*px+1:yy*px) = img_gray( (ii-1)*bpx+5:ii*bpx-4, (jj-1)*bpy+5:jj*bpy-4 );
            end

        end
    end
    end
    
end

imagesc(mural)
colormap gray
axis off


% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Perform rotations to create a dataset with lots of rotations
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 

rng(seed);
tr_subset = randsample(TOTAL_IMGS,tr/36);

count = 0;
Y_TRAIN = zeros(d,tr);
for ii = 1 : tr/36
    img_sub = Y_RAW(:,:,tr_subset(ii));
    for arg = 1 : 36
        img_crop = rotate_and_crop(img_sub,arg*10);
        count = count + 1;
        picvec = img_crop(:);
        picvec = double(picvec);
        Y_TRAIN(:,count) = picvec;
    end
end

% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
% Creating Test Sets
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
train_index = setdiff(1:TOTAL_IMGS,tr_subset);
tr_index = randsample(train_index,te/36);

% Create test sets
count = 0;
Y_TEST = zeros(d,te);
for ii = 1 : te/36
    img_sub = Y_RAW(:,:,tr_index(1,ii));
    for arg = 1 : 36
        img_crop = rotate_and_crop(img_sub,arg*10);
        count = count + 1;
        picvec = img_crop(:);
        picvec = double(picvec);
        Y_TEST(:,count) = picvec;
    end
end

% Center training set
Y_CENTER = mean(Y_TRAIN,2);
Y_TRAIN = Y_TRAIN - Y_CENTER * ones(1,tr);
for i = 1 : tr
    Y_TRAIN(:,i) = Y_TRAIN(:,i) / norm(Y_TRAIN(:,i),2);
end

save('data.mat','Y_TRAIN','Y_TEST','Y_CENTER');