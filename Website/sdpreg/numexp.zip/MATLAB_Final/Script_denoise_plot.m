% Plot comparison graph
run('graph_denoise_extractsigma')
run('graph_denoise_format')
run('graph_denoise_plot')